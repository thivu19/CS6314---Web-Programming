function myFunction() {
    var myBodyTitle = document.getElementById("body").nodeName;
    var myBodyTitleV = document.getElementById("body").nodeValue;
    var myBodyTitleT = document.getElementById("body").nodeType;
    document.getElementById("id1").innerHTML = myBodyTitle + myBodyTitleV + myBodyTitleT;

    var myBodyChild = document.getElementById("body").childNodes[0].nodeName;
    var myBodyChildV = document.getElementById("body").childNodes[0].nodeValue;
    var myBodyChildT = document.getElementById("body").childNodes[0].nodeType;
    document.getElementById("id2").innerHTML = myBodyChild + myBodyChildV + myBodyChildT;

    var myBodyChild2 = document.getElementById("body").childNodes[1].nodeName;
    var myBodyChild2V = document.getElementById("body").childNodes[1].nodeValue;
    var myBodyChild2T = document.getElementById("body").childNodes[1].nodeType;
    document.getElementById("id3").innerHTML = myBodyChild2 + myBodyChild2V + myBodyChild2T;

    // Attributes
    var myA1 = document.getElementById("a1").nodeName;
    var myA1V = document.getElementById("a1").nodeValue;
    var myA1T = document.getElementById("a1").nodeType;
    document.getElementById("id4").innerHTML = myA1 + myA1V + myA1T;
    //document.getElementById("id1").innerHTML = document.getElementById("body").firstChild.nodeValue;
} 